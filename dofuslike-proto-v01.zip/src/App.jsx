
import React, { useEffect, useMemo, useState } from "react";

const GRID_W = 10;
const GRID_H = 8;
const MAX_MP = 3;
const MAX_AP = 4;

const key = (x, y) => `${x},${y}`;
const manhattan = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
const inBounds = (x, y) => x >= 0 && y >= 0 && x < GRID_W && y < GRID_H;

const makeUnit = ({ id, name, team, x, y, hp = 20, ap = MAX_AP, mp = MAX_MP, range = 1, dmg = 5 }) => ({
  id, name, team, x, y, hp, ap, mp, range, dmg, alive: true
});

function initialUnits() {
  return [
    makeUnit({ id: "P1", name: "Héros", team: "player", x: 1, y: 6, range: 2 }),
    makeUnit({ id: "P2", name: "Archer", team: "player", x: 2, y: 6, range: 3, dmg: 4 }),
    makeUnit({ id: "E1", name: "Bouftou", team: "enemy", x: 7, y: 1 }),
    makeUnit({ id: "E2", name: "Larve", team: "enemy", x: 8, y: 2, hp: 16, dmg: 4 }),
  ];
}

export default function App() {
  const [tab, setTab] = useState("play");
  const [units, setUnits] = useState(initialUnits);
  const [turnIndex, setTurnIndex] = useState(0);
  const [selectedId, setSelectedId] = useState(null);
  const [log, setLog] = useState(["Bienvenue ! Votre tour commence."]);
  const [hover, setHover] = useState(null);

  const aliveUnits = useMemo(() => units.filter(u => u.alive), [units]);
  const turnOrder = useMemo(() => aliveUnits, [aliveUnits]);
  const current = turnOrder[turnIndex % (turnOrder.length || 1)];

  const unitAt = useMemo(() => {
    const map = new Map();
    for (const u of aliveUnits) map.set(key(u.x, u.y), u);
    return map;
  }, [aliveUnits]);

  const isPlayerTurn = current?.team === "player";

  useEffect(() => {
    if (!current) return;
    setUnits(prev => prev.map(u => (u.id === current.id ? { ...u, ap: MAX_AP, mp: MAX_MP } : u)));
  }, [current?.id]);

  useEffect(() => {
    const playersAlive = aliveUnits.some(u => u.team === "player");
    const enemiesAlive = aliveUnits.some(u => u.team === "enemy");
    if (!playersAlive || !enemiesAlive) {
      setLog(l => [!playersAlive ? "Défaite..." : "Victoire !", ...l]);
    }
  }, [aliveUnits]);

  function selectUnit(u) {
    if (!isPlayerTurn) return;
    if (u.team !== "player") return;
    setSelectedId(u.id);
  }

  function canMoveTo(u, x, y) {
    if (!inBounds(x, y)) return false;
    if (unitAt.has(key(x, y))) return false;
    const dist = manhattan(u, { x, y });
    return dist > 0 && dist <= u.mp;
  }

  function moveSelectedTo(x, y) {
    if (!isPlayerTurn) return;
    const sel = aliveUnits.find(u => u.id === selectedId);
    if (!sel) return;
    if (!canMoveTo(sel, x, y)) return;
    const cost = manhattan(sel, { x, y });
    setUnits(prev => prev.map(u => (u.id === sel.id ? { ...u, x, y, mp: Math.max(0, u.mp - cost) } : u)));
    pushLog(`${sel.name} se déplace en (${x},${y}).`);
  }

  function canAttack(attacker, target) {
    if (attacker.id === target.id) return false;
    if (attacker.team === target.team) return false;
    if (attacker.ap <= 0) return false;
    const dist = manhattan(attacker, target);
    return dist >= 1 && dist <= attacker.range;
  }

  function attack(target) {
    if (!isPlayerTurn) return;
    const attacker = aliveUnits.find(u => u.id === selectedId);
    if (!attacker) return;
    if (!canAttack(attacker, target)) return;
    setUnits(prev =>
      prev.map(u => {
        if (u.id === attacker.id) return { ...u, ap: u.ap - 2 < 0 ? 0 : u.ap - 2 };
        if (u.id === target.id) {
          const hp = u.hp - attacker.dmg;
          return { ...u, hp, alive: hp > 0 };
        }
        return u;
      })
    );
    pushLog(`${attacker.name} attaque ${target.name} (−${attacker.dmg} PV).`);
  }

  function endTurn() {
    if (!current) return;
    setTurnIndex(i => (i + 1) % turnOrder.length);
    setSelectedId(null);
  }

  function pushLog(msg) {
    setLog(l => [msg, ...l].slice(0, 12));
  }

  useEffect(() => {
    if (!current || current.team !== "enemy") return;
    const t = setTimeout(() => {
      const players = aliveUnits.filter(u => u.team === "player");
      if (players.length === 0) return;
      const target = players.slice().sort((a, b) => manhattan(current, a) - manhattan(current, b))[0];
      const dist = manhattan(current, target);
      if (dist >= 1 && dist <= current.range && current.ap >= 2) {
        setUnits(prev =>
          prev.map(u => {
            if (u.id === current.id) return { ...u, ap: u.ap - 2 };
            if (u.id === target.id) {
              const hp = u.hp - current.dmg;
              return { ...u, hp, alive: hp > 0 };
            }
            return u;
          })
        );
        pushLog(`${current.name} frappe ${target.name} (−${current.dmg} PV).`);
        setTimeout(() => endTurn(), 300);
      } else {
        let best = { x: current.x, y: current.y, d: dist };
        const dirs = [{x:1,y:0},{x:-1,y:0},{x:0,y:1},{x:0,y:-1}];
        let steps = current.mp;
        let cx = current.x, cy = current.y;
        for (let s = 0; s < steps; s++) {
          let moved = FalseLike();
          for (const dxy of dirs) {
            const nx = cx + dxy.x;
            const ny = cy + dxy.y;
            if (!inBounds(nx, ny)) continue;
            if (unitAt.has(key(nx, ny))) continue;
            const nd = Math.abs(nx - target.x) + Math.abs(ny - target.y);
            if (nd < best.d) {
              best = { x: nx, y: ny, d: nd };
              cx = nx; cy = ny;
              moved = true;
              break;
            }
          }
          if (!moved) break;
        }
        if (best.x !== current.x || best.y !== current.y) {
          setUnits(prev => prev.map(u => (u.id === current.id ? { ...u, x: best.x, y: best.y, mp: 0 } : u)));
          pushLog(`${current.name} se rapproche…`);
        }
        setTimeout(() => endTurn(), 300);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [current?.id]);

  function FalseLike() { return false; } // helper to keep the logic readable

  const gdd = `# GDD Résumé — Dofus‑like (v0.1)

## Vision
Tactical MMORPG 2D au tour par tour sur grille, combat stratégique, progression riche (sorts, métiers, économie), style cartoon.

## Boucle de jeu
1. Exploration de cartes reliées (instances légères).
2. Combat tour par tour sur grille orthogonale.
3. Récompenses: XP, butin, ressources.
4. Craft/métiers, hôtel de vente, quêtes, progression de sorts.

## Systèmes clés
- Caractéristiques: PV, PA, PM, Portée, Initiative, Résistances.
- Actions: Déplacement (PM), Attaque (PA), Sorts (coûts variables).
- États: Tacle, Enraciné, etc.
- Ligne de vue: à ajouter (obstacles + diagonales).

## Multijoueur (roadmap)
- v0→v1: Solo → Coop local → En ligne.
- Tech: Node + WebSocket, autorité serveur, états déterministes.
`;

  return (
    <div className="container">
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <h1 style={{fontSize:24,fontWeight:800}}>Dofus‑like — Prototype (v0.1)</h1>
        <div className="tabs">
          <button onClick={() => setTab("play")} className={tab==="play"?"active":""}>Jouer</button>
          <button onClick={() => setTab("gdd")} className={tab==="gdd"?"active":""}>GDD</button>
        </div>
      </header>

      {tab === "play" ? (
        <div className="layout">
          <div className="card" style={{padding:12}}>
            <div className="grid board">
              {Array.from({ length: GRID_H }).map((_, y) => (
                <React.Fragment key={y}>
                  {Array.from({ length: GRID_W }).map((_, x) => {
                    const u = unitAt.get(key(x,y));
                    const sel = selectedId ? aliveUnits.find(z => z.id === selectedId) : null;
                    const canMove = isPlayerTurn && sel && !u && canMoveTo(sel, x, y);
                    const danger = u && sel && canAttack(sel, u);
                    const cls = `cell ${(x + y) % 2 === 0 ? "a" : "b"} ${canMove ? "ok" : ""} ${danger ? "danger" : ""}`;
                    return (
                      <button
                        title={`(${x},${y})`}
                        key={`${x}-${y}`}
                        className={cls}
                        onMouseEnter={() => setHover({x,y})}
                        onMouseLeave={() => setHover(null)}
                        onClick={() => {
                          if (u) {
                            if (u.team === "player") selectUnit(u);
                            else if (selectedId) attack(u);
                          } else if (selectedId) {
                            moveSelectedTo(x, y);
                          }
                        }}
                      >
                        {u && (
                          <div style={{textAlign:'center'}}>
                            <div style={{fontWeight:600, color: u.team==="player"?"#047857":"#be123c"}}>{u.name}</div>
                            <div className="muted" style={{fontSize:11}}>HP {u.hp}</div>
                          </div>
                        )}
                      </button>
                    )
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>

          <aside className="card sidebar">
            <h2 style={{marginTop:0}}>Tour</h2>
            {current ? (
              <div className="pill">
                <div className="muted" style={{fontSize:13}}>Acteur actuel</div>
                <div style={{fontWeight:700, color: current.team==="player"?"#047857":"#be123c"}}>{current.name}</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8, marginTop:8}}>
                  <Row label="HP" value={current.hp} />
                  <Row label="PA" value={current.ap} />
                  <Row label="PM" value={current.mp} />
                  <Row label="Portée" value={current.range} />
                </div>
              </div>
            ) : <div>Aucun acteur.</div>}

            <div style={{display:'flex', gap:8, marginTop:8}}>
              <button className="btn primary" onClick={() => setSelectedId(current?.id)} disabled={!isPlayerTurn || current?.team !== "player"}>Sélectionner</button>
              <button className="btn" onClick={endTurn}>Fin de tour</button>
              <button className="btn" onClick={() => { setUnits(initialUnits()); setTurnIndex(0); setSelectedId(null); setLog(["Combat réinitialisé."]); }}>Reset</button>
            </div>

            <div>
              <h3>Unités</h3>
              <div className="list">
                {aliveUnits.map(u => (
                  <button key={u.id} onClick={() => selectUnit(u)} className="btn" style={{display:'block', width:'100%', textAlign:'left', marginBottom:6}}>
                    <div className="row">
                      <span style={{color: u.team==="player"?"#047857":"#be123c"}}>{u.name}</span>
                      <span className="muted" style={{fontSize:12}}>({u.x},{u.y})</span>
                    </div>
                    <div className="muted" style={{fontSize:12}}>HP {u.hp} · PA {u.ap} · PM {u.mp}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3>Journal</h3>
              <div className="log">
                {log.map((m,i)=>(<div key={i}>• {m}</div>))}
              </div>
            </div>
          </aside>
        </div>
      ) : (
        <div className="card" style={{padding:16}}>
          <Markdown text={gdd} />
        </div>
      )}

      <footer className="muted" style={{marginTop:16, fontSize:12}}>
        v0.1 — Déplacement (PM), Attaque (PA), IA simple, portée, victoire/défaite. Prochaines étapes: ligne de vue, obstacles, sorts, online.
      </footer>
    </div>
  );
}

function Row({label, value}){
  return <div className="row"><span className="muted">{label}</span><span style={{fontWeight:600}}>{value}</span></div>
}

function Markdown({ text }) {
  const lines = text.split("\\n");
  const rendered = [];
  let buffer = [];
  function flushPara() {
    if (buffer.length) {
      rendered.push(<p key={rendered.length}>{buffer.join(" ")}</p>);
      buffer = [];
    }
  }
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (l.startsWith("# ")) { flushPara(); rendered.push(<h1 key={rendered.length}>{l.slice(2)}</h1>); continue; }
    if (l.startsWith("## ")) { flushPara(); rendered.push(<h2 key={rendered.length}>{l.slice(3)}</h2>); continue; }
    if (l.startsWith("- ")) {
      const items = [l.slice(2)];
      while (i + 1 < lines.length && lines[i + 1].startsWith("- ")) { items.push(lines[++i].slice(2)); }
      flushPara();
      rendered.push(<ul key={rendered.length} style={{paddingLeft:20}}>{items.map((it, idx) => <li key={idx}>{it}</li>)}</ul>);
      continue;
    }
    if (l.trim() === "") { flushPara(); continue; }
    buffer.push(l);
  }
  flushPara();
  return <div className="prose">{rendered}</div>;
}
